#include "solver.hpp"
#include "geometry.hpp"
#include "propagation.hpp"
#include "dfs.hpp"
#include <sstream>

SudokuSolver::SudokuSolver(){
    geom::init();
    S_.trail = &trail_;
    trail_.reserve(1<<16);
}

bool SudokuSolver::solve(const std::string& puzzle){
    S_.init_from_puzzle(puzzle);
    // Initial propagation: for any pre-fixed cells, queues were primed
    if(!propagate(S_)) return false;
    return dfs(S_);
}

std::string SudokuSolver::solution_string() const{
    std::ostringstream oss;
    for(int i=0;i<81;++i){
        int v = S_.cell_value[i];
        if(v==0){
            // produce a best-effort candidate (optional)
            oss << '0';
        }else{
            oss << char('0' + v);
        }
    }
    return oss.str();
}
