#include <iostream>
#include <string>
#include "solver.hpp"

int main(int argc, char** argv){
    // Example: read single puzzle from argv or use a default easy one.
    std::string puzzle =
        (argc>1 ? argv[1] :
         "53..7...."
         "6..195..."
         ".98....6."
         "8...6...3"
         "4..8.3..1"
         "7...2...6"
         ".6....28."
         "...419..5"
         "....8..79");

    SudokuSolver solver;
    bool ok = solver.solve(puzzle);
    if(!ok){
        std::cout << "UNSOLVED/CONTRADICTION\n";
        return 1;
    }
    std::cout << solver.solution_string() << "\n";
    return 0;
}
