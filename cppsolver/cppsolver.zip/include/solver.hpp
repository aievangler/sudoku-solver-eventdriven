#pragma once
#include <string>
#include "state.hpp"
#include "trail.hpp"

class SudokuSolver {
public:
    SudokuSolver();
    bool solve(const std::string& puzzle);
    std::string solution_string() const;

private:
    SolverState S_;
    Trail trail_;
};
